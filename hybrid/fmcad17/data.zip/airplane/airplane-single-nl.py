
# import the model.
from airplaneSingleNl import *

#############
# Init/Goal #
#############

# Define initial conditions for each variable. For example, the expression
# (= tau_{0}_0 0) declares that the value of tau at the beginning is 0, 
# where {0} will be replaced by 0.
init_cond = """
(assert (and (= tau_{0}_0 0)  (= gRDR_{0}_0 0) (= gAIL_{0}_0 0) (= psi_{0}_0 0) 
             (= phi_{0}_0 0)  (= r_{0}_0 0)    (= p_{0}_0 0)    (= beta_{0}_0 0)
	     (< 0.5 gDir_{0}_0) (< gDir_{0}_0 0.7)))
(assert (and (= xAIL_{0}_0 0) (= modeA_{0} true)))
(assert (and (= xRDR_{0}_0 0) (= modeR_{0} true)))
"""

# Define the goal condition, where {0} will be replaced by k, the last step.
goal_cond = """
(assert (> (^ (^ beta_{0}_t 2) 0.5) 0.2))
"""

# Generate the smt2 output.
import sys
try:
    bound = int(sys.argv[1])
except:
    print("Usage:", sys.argv[0], "<Bound>")
else:
    generate(bound, 1, [0], 0, init_cond, goal_cond)

