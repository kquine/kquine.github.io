
from gen import *

##########
# shared #
##########

# declare ODE variable
flow_var[0] = """
(declare-fun x0 () Real)
(declare-fun y0 () Real)
(declare-fun v0 () Real)
(declare-fun th0 () Real)
(declare-fun ph0 () Real)
(declare-fun x1 () Real)
(declare-fun y1 () Real)
(declare-fun v1 () Real)
(declare-fun th1 () Real)
(declare-fun ph1 () Real)
(declare-fun x2 () Real)
(declare-fun y2 () Real)
(declare-fun v2 () Real)
(declare-fun th2 () Real)
(declare-fun ph2 () Real)
"""

# declare ODE for the continuous dynamics (no free variable allowed)
flow_dec[0] = """
(define-ode flow_1 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] (* -1 (- v1 v0)))
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] (* -1 (- v2 v1)))))
(define-ode flow_2 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] (* -1 (- v1 v0)))
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] 5)))
(define-ode flow_3 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] (* -1 (- v1 v0)))
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] -5)))
(define-ode flow_4 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] 5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] (* -1 (- v2 v1)))))
(define-ode flow_5 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] 5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] 5)))
(define-ode flow_6 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] 5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] -5)))
(define-ode flow_7 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] -5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] (* -1 (- v2 v1)))))
(define-ode flow_8 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] -5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] 5)))
(define-ode flow_9 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0) 
                    (= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] -5)
                    (= d/dt[x2] (* v2 (cos th2))) (= d/dt[y2] (* v2 (sin th2))) (= d/dt[th2] (* (/ v2 1) (/ (sin ph2) (cos ph2)))) (= d/dt[ph2] (* -1 (- ph2 ph1))) (= d/dt[v2] -5)))
"""

# declare state variables for each step, where {0} is replaced 
# by the step number.
state_dec[0] = """
(declare-fun x0_{0}_0 () Real)
(declare-fun x0_{0}_t () Real)
(declare-fun y0_{0}_0 () Real)
(declare-fun y0_{0}_t () Real)
(declare-fun v0_{0}_0 () Real)
(declare-fun v0_{0}_t () Real)
(declare-fun th0_{0}_0 () Real)
(declare-fun th0_{0}_t () Real)
(declare-fun ph0_{0}_0 () Real)
(declare-fun ph0_{0}_t () Real)
(declare-fun x1_{0}_0 () Real)
(declare-fun x1_{0}_t () Real)
(declare-fun y1_{0}_0 () Real)
(declare-fun y1_{0}_t () Real)
(declare-fun v1_{0}_0 () Real)
(declare-fun v1_{0}_t () Real)
(declare-fun th1_{0}_0 () Real)
(declare-fun th1_{0}_t () Real)
(declare-fun ph1_{0}_0 () Real)
(declare-fun ph1_{0}_t () Real)
(declare-fun mode1_{0} () Real)
(declare-fun x2_{0}_0 () Real)
(declare-fun x2_{0}_t () Real)
(declare-fun y2_{0}_0 () Real)
(declare-fun y2_{0}_t () Real)
(declare-fun v2_{0}_0 () Real)
(declare-fun v2_{0}_t () Real)
(declare-fun th2_{0}_0 () Real)
(declare-fun th2_{0}_t () Real)
(declare-fun ph2_{0}_0 () Real)
(declare-fun ph2_{0}_t () Real)
(declare-fun mode2_{0} () Real)
(declare-fun time_{0} () Real)
"""

# declare constraints for state variables for each step, 
# where {0} is replaced by the step number.
state_val[0] = """
(assert (<= 0 x0_{0}_0))     (assert (<= x0_{0}_0 100))
(assert (<= 0 x0_{0}_t))     (assert (<= x0_{0}_t 100))
(assert (<= 0 y0_{0}_0))     (assert (<= y0_{0}_0 100))
(assert (<= 0 y0_{0}_t))     (assert (<= y0_{0}_t 100))
(assert (<= 0 v0_{0}_0))     (assert (<= v0_{0}_0 10))
(assert (<= 0 v0_{0}_t))     (assert (<= v0_{0}_t 10))
(assert (<= -1.5 th0_{0}_0)) (assert (<= th0_{0}_0 1.5))
(assert (<= -1.5 th0_{0}_t)) (assert (<= th0_{0}_t 1.5))
(assert (<= -1 ph0_{0}_0))   (assert (<= ph0_{0}_0 1))
(assert (<= -1 ph0_{0}_t))   (assert (<= ph0_{0}_t 1))
(assert (<= 0 x1_{0}_0))     (assert (<= x1_{0}_0 100))
(assert (<= 0 x1_{0}_t))     (assert (<= x1_{0}_t 100))
(assert (<= 0 y1_{0}_0))     (assert (<= y1_{0}_0 100))
(assert (<= 0 y1_{0}_t))     (assert (<= y1_{0}_t 100))
(assert (<= 0 v1_{0}_0))     (assert (<= v1_{0}_0 10))
(assert (<= 0 v1_{0}_t))     (assert (<= v1_{0}_t 10))
(assert (<= -1.5 th1_{0}_0)) (assert (<= th1_{0}_0 1.5))
(assert (<= -1.5 th1_{0}_t)) (assert (<= th1_{0}_t 1.5))
(assert (<= -1 ph1_{0}_0))   (assert (<= ph1_{0}_0 1))
(assert (<= -1 ph1_{0}_t))   (assert (<= ph1_{0}_t 1))
(assert (<= 1 mode1_{0}))    (assert (<= mode1_{0} 3))
(assert (<= 0 x2_{0}_0))     (assert (<= x2_{0}_0 100))
(assert (<= 0 x2_{0}_t))     (assert (<= x2_{0}_t 100))
(assert (<= 0 y2_{0}_0))     (assert (<= y2_{0}_0 100))
(assert (<= 0 y2_{0}_t))     (assert (<= y2_{0}_t 100))
(assert (<= 0 v2_{0}_0))     (assert (<= v2_{0}_0 10))
(assert (<= 0 v2_{0}_t))     (assert (<= v2_{0}_t 10))
(assert (<= -1.5 th2_{0}_0)) (assert (<= th2_{0}_0 1.5))
(assert (<= -1.5 th2_{0}_t)) (assert (<= th2_{0}_t 1.5))
(assert (<= -1 ph2_{0}_0))   (assert (<= ph2_{0}_0 1))
(assert (<= -1 ph2_{0}_t))   (assert (<= ph2_{0}_t 1))
(assert (<= 1 mode2_{0}))    (assert (<= mode2_{0} 3))
(assert (<= 0 time_{0} [0.000000])) (assert (<= time_{0} 1 [0.000000]))
"""

# declare formulas for flow conditions for each step {0}. 
# The integral function is the ODE solution operator, but not parameterized.
cont_cond[0] = ["""
(assert (or
  (and (= mode1_{0} 1) (= mode2_{0} 1)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_1)))
  (and (= mode1_{0} 1) (= mode2_{0} 2)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_2)))
  (and (= mode1_{0} 1) (= mode2_{0} 3)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_3)))
  (and (= mode1_{0} 2) (= mode2_{0} 1)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_4)))
  (and (= mode1_{0} 2) (= mode2_{0} 2)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_5)))
  (and (= mode1_{0} 2) (= mode2_{0} 3)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_6)))
  (and (= mode1_{0} 3) (= mode2_{0} 1)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_7)))
  (and (= mode1_{0} 3) (= mode2_{0} 2)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_8)))
  (and (= mode1_{0} 3) (= mode2_{0} 3)
       (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t x2_{0}_t y2_{0}_t th2_{0}_t ph2_{0}_t v2_{0}_t] 
          (integral 0. time_{0} [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0 x2_{0}_0 y2_{0}_0 th2_{0}_0 ph2_{0}_0 v2_{0}_0] flow_9)))))
"""]


# define jump conditions from step {0} to step {1}.
jump_cond[0] = ["""
(assert (and (= x0_{1}_0 x0_{0}_t) (= y0_{1}_0 y0_{0}_t) 
             (= v0_{1}_0 v0_{0}_t) (= ph0_{1}_0 ph0_{0}_t) (= th0_{1}_0 th0_{0}_t)))
(assert (and (= x1_{1}_0 x1_{0}_t) (= y1_{1}_0 y1_{0}_t) 
             (= v1_{1}_0 v1_{0}_t) (= ph1_{1}_0 ph1_{0}_t) (= th1_{1}_0 th1_{0}_t)))
(assert (or
  (and (= mode1_{0} 1)
       (or (and (= mode1_{1} 3) (<= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2))) 
           (and (= mode1_{1} 2) (>= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))) 
           (and (= mode1_{1} 1) (>  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2)) 
                                (<  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2)))))
  (and (= mode1_{0} 2)
       (or (and (= mode1_{1} 2) (>= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))) 
           (and (= mode1_{1} 1) (<  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))))) 
  (and (= mode1_{0} 3)
       (or (and (= mode1_{1} 3) (<= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2))) 
           (and (= mode1_{1} 1) (>  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2)))))))
(assert (and (= x2_{1}_0 x2_{0}_t) (= y2_{1}_0 y2_{0}_t) 
             (= v2_{1}_0 v2_{0}_t) (= ph2_{1}_0 ph2_{0}_t) (= th2_{1}_0 th2_{0}_t)))
(assert (or
  (and (= mode2_{0} 1)
       (or (and (= mode2_{1} 3) (<= (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 5 2))) 
           (and (= mode2_{1} 2) (>= (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 10 2))) 
           (and (= mode2_{1} 1) (>  (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 5 2)) 
                                (<  (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 10 2)))))
  (and (= mode2_{0} 2)
       (or (and (= mode2_{1} 2) (>= (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 10 2))) 
           (and (= mode2_{1} 1) (<  (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 10 2))))) 
  (and (= mode2_{0} 3)
       (or (and (= mode2_{1} 3) (<= (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 5 2))) 
           (and (= mode2_{1} 1) (>  (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) (^ 5 2)))))))
"""]

