
# import the model.
from carTripleP import *

#############
# Init/Goal #
#############

# Define initial conditions for each variable. For example, the expression
# (= x0_{0}_0 0) declares that the value of x0 at the beginning is 0, 
# where {0} will be replaced by 0.
init_cond = """
(assert (and (= x0_{0}_0 50) (= y0_{0}_0 50) (= th0_{0}_0 0.5) (= ph0_{0}_0 0.01) (< v0_{0}_0 7) (< 5 v0_{0}_0)))
(assert (and (= x1_{0}_0 25) (= y1_{0}_0 25) (= th1_{0}_0 0)   (= ph1_{0}_0 0)    (= v1_{0}_0 5)))
(assert (and (= mode1_{0} 1))) 
(assert (and (= x2_{0}_0 0)  (= y2_{0}_0 0)  (= th2_{0}_0 0)   (= ph2_{0}_0 0)    (= v2_{0}_0 5)))
(assert (and (= mode2_{0} 1))) 
"""

# Define the goal condition, where {0} will be replaced by k, the last step.
goal_cond = """
(assert (and (= mode1_{0} 1) (< (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) 100)))
(assert (and (= mode2_{0} 1) (< (+ (^ (- x1_{0}_t x2_{0}_t) 2) (^ (- y1_{0}_t y2_{0}_t) 2)) 100)))
"""

# Generate the smt2 output.
import sys
try:
    bound = int(sys.argv[1])
except:
    print("Usage:", sys.argv[0], "<Bound>")
else:
    generate(bound, 1, [0,1,2], 3, init_cond, goal_cond)

