
# import the model.
from carDoubleP import *

#############
# Init/Goal #
#############

# Define initial conditions for each variable. For example, the expression
# (= x0_{0}_0 0) declares that the value of x0 at the beginning is 0, 
# where {0} will be replaced by 0.
init_cond = """
(assert (and (= x0_{0}_0 50) (= y0_{0}_0 50) (= th0_{0}_0 0.5) (= ph0_{0}_0 0.01) (< v0_{0}_0 7) (< 5 v0_{0}_0)))
(assert (and (= x1_{0}_0 0)  (= y1_{0}_0 0)  (= th1_{0}_0 0)   (= ph1_{0}_0 0)    (= v1_{0}_0 5)))
(assert (and (= mode_{0} 1))) 
"""

# Define the goal condition, where {0} will be replaced by k, the last step.
goal_cond = """
(assert (and (= mode_{0} 1) (< (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) 100)))
"""

# Generate the smt2 output.
import sys
try:
    bound = int(sys.argv[1])
except:
    print("Usage:", sys.argv[0], "<Bound>")
else:
    generate(bound, 1, [0,1], 2, init_cond, goal_cond)

