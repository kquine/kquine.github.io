
# import the model.
from batteryTriple import *

#############
# Init/Goal #
#############

# Define initial conditions for each variable. For example, the expression
# (= tau_{0}_0 0) declares that the value of tau at the beginning is 0, 
# where {0} will be replaced by 0.
init_cond = """
(assert (= tau_{0}_0 0))
(assert (and mode1U_{0} mode1L_{0}))
(assert (and (= g1_{0}_0 8.5) (= d1_{0}_0 0)))
(assert (and mode2U_{0} mode2L_{0}))
(assert (and (= g2_{0}_0 7.5) (= d2_{0}_0 0)))
(assert (and mode3U_{0} mode3L_{0}))
(assert (and (= g3_{0}_0 9.5) (= d3_{0}_0 0)))
"""

# Define the goal condition, where {0} will be replaced by k, the last step.
goal_cond = """
(assert (and (>= tau_{0}_t 10)
             (not (and (= mode1L_{0} false) (= mode1U_{0} false) 
                       (= mode2L_{0} false) (= mode2U_{0} false)
                       (= mode3L_{0} false) (= mode3U_{0} false)))))
"""

# Generate the smt2 output.
import sys
try:
    bound = int(sys.argv[1])
except:
    print("Usage:", sys.argv[0], "<Bound>")
else:
    generate(bound, 1, [0], 0, init_cond, goal_cond)

