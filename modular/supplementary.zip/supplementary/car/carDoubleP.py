
from gen import *

#########
# car 0 #
#########

# declare ODE variable
flow_var[0] = """
(declare-fun y0 () Real)
(declare-fun x0 () Real)
(declare-fun v0 () Real)
(declare-fun th0 () Real)
(declare-fun ph0 () Real)
"""

# declare ODE for the first car
flow_dec[0] = """
(define-ode flow_1 ((= d/dt[x0] (* v0 (cos th0))) (= d/dt[y0] (* v0 (sin th0))) (= d/dt[th0] (* (/ v0 1) (/ (sin ph0) (cos ph0)))) (= d/dt[ph0] 0) (= d/dt[v0] 0)))
"""

# declare state variables for each step, where {0} is replaced 
# by the step number.
state_dec[0] = """
(declare-fun x0_{0}_0 () Real)
(declare-fun x0_{0}_t () Real)
(declare-fun y0_{0}_0 () Real)
(declare-fun y0_{0}_t () Real)
(declare-fun v0_{0}_0 () Real)
(declare-fun v0_{0}_t () Real)
(declare-fun th0_{0}_0 () Real)
(declare-fun th0_{0}_t () Real)
(declare-fun ph0_{0}_0 () Real)
(declare-fun ph0_{0}_t () Real)
(declare-fun time_{0} () Real)
"""

# declare constraints for state variables for each step, 
# where {0} is replaced by the step number.
state_val[0] = """
(assert (<= 0 x0_{0}_0))     (assert (<= x0_{0}_0 100))
(assert (<= 0 x0_{0}_t))     (assert (<= x0_{0}_t 100))
(assert (<= 0 y0_{0}_0))     (assert (<= y0_{0}_0 100))
(assert (<= 0 y0_{0}_t))     (assert (<= y0_{0}_t 100))
(assert (<= 0 v0_{0}_0))     (assert (<= v0_{0}_0 10))
(assert (<= 0 v0_{0}_t))     (assert (<= v0_{0}_t 10))
(assert (<= -1.5 th0_{0}_0)) (assert (<= th0_{0}_0 1.5))
(assert (<= -1.5 th0_{0}_t)) (assert (<= th0_{0}_t 1.5))
(assert (<= -1 ph0_{0}_0))   (assert (<= ph0_{0}_0 1))
(assert (<= -1 ph0_{0}_t))   (assert (<= ph0_{0}_t 1))
(assert (<= 0 time_{0} [0.000000])) (assert (<= time_{0} 1 [0.000000]))
"""

# declare formulas for flow conditions for each step {0}. 
# the pintegral function is the ODE solution operator,
# holder denotes a vector of functions, and the connect formula 
# semantically defines a universally quantified assignment, 
# provided that the domain of every holder function is the same.
cont_cond[0] = ["""
(assert 
    (and (= [x0_{0}_t y0_{0}_t th0_{0}_t ph0_{0}_t v0_{0}_t x1_{0}_t y1_{0}_t th1_{0}_t ph1_{0}_t v1_{0}_t] 
            (pintegral 
                0. time_{0} 
                [x0_{0}_0 y0_{0}_0 th0_{0}_0 ph0_{0}_0 v0_{0}_0 x1_{0}_0 y1_{0}_0 th1_{0}_0 ph1_{0}_0 v1_{0}_0] 
                [holder_{1} holder_{2}]))
         (connect holder_{1} flow_1)))
"""]


# define jump conditions from step {0} to step {1}.
jump_cond[0] = ["""
(assert (and (= x0_{1}_0 x0_{0}_t) (= y0_{1}_0 y0_{0}_t) 
             (= v0_{1}_0 v0_{0}_t) (= ph0_{1}_0 ph0_{0}_t) (= th0_{1}_0 th0_{0}_t)))
"""]

#########
# Car 1 #
#########

# declare ODE variable
flow_var[1] = """
(declare-fun y1 () Real)
(declare-fun x1 () Real)
(declare-fun v1 () Real)
(declare-fun th1 () Real)
(declare-fun ph1 () Real)
"""

# declare ODE for a single battery
flow_dec[1] = """
(define-ode flow_2 ((= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] (* -1 (- v1 v0)))))
(define-ode flow_3 ((= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] 5)))
(define-ode flow_4 ((= d/dt[x1] (* v1 (cos th1))) (= d/dt[y1] (* v1 (sin th1))) (= d/dt[th1] (* (/ v1 1) (/ (sin ph1) (cos ph1)))) (= d/dt[ph1] (* -1 (- ph1 ph0))) (= d/dt[v1] -5)))
"""

# declare state variables for each step, where {0} is replaced 
# by the step number.
state_dec[1] = """
(declare-fun y1_{0}_0 () Real)
(declare-fun y1_{0}_t () Real)
(declare-fun x1_{0}_0 () Real)
(declare-fun x1_{0}_t () Real)
(declare-fun v1_{0}_0 () Real)
(declare-fun v1_{0}_t () Real)
(declare-fun th1_{0}_0 () Real)
(declare-fun th1_{0}_t () Real)
(declare-fun ph1_{0}_0 () Real)
(declare-fun ph1_{0}_t () Real)
(declare-fun mode_{0} () Real)
"""

# declare constraints for state variables for each step, 
# where {0} is replaced by the step number.
state_val[1] = """
(assert (<= 0 x1_{0}_0))     (assert (<= x1_{0}_0 100))
(assert (<= 0 x1_{0}_t))     (assert (<= x1_{0}_t 100))
(assert (<= 0 y1_{0}_0))     (assert (<= y1_{0}_0 100))
(assert (<= 0 y1_{0}_t))     (assert (<= y1_{0}_t 100))
(assert (<= 0 v1_{0}_0))     (assert (<= v1_{0}_0 10))
(assert (<= 0 v1_{0}_t))     (assert (<= v1_{0}_t 10))
(assert (<= -1.5 th1_{0}_0)) (assert (<= th1_{0}_0 1.5))
(assert (<= -1.5 th1_{0}_t)) (assert (<= th1_{0}_t 1.5))
(assert (<= -1 ph1_{0}_0))   (assert (<= ph1_{0}_0 1))
(assert (<= -1 ph1_{0}_t))   (assert (<= ph1_{0}_t 1))
(assert (<= 1 mode_{0}))     (assert (<= mode_{0} 3))
"""

# declare formulas for flow conditions for each step {0}. 
# holder denotes a vector of functions, and the connect formula 
# semantically defines a universally quantified assignment, 
# provided that the domain of every holder function is the same.
cont_cond[1] = ["""
(assert (or (and (= mode_{0} 1) (connect holder_{2} flow_2))
            (and (= mode_{0} 2) (connect holder_{2} flow_3))
            (and (= mode_{0} 3) (connect holder_{2} flow_4))))
(assert (not (and (connect holder_{2} flow_2) (connect holder_{2} flow_3))))
(assert (not (and (connect holder_{2} flow_2) (connect holder_{2} flow_4))))
(assert (not (and (connect holder_{2} flow_3) (connect holder_{2} flow_4))))
"""]


# define jump conditions from step {0} to step {1}.
jump_cond[1] = ["""
(assert (and (= x1_{1}_0 x1_{0}_t) (= y1_{1}_0 y1_{0}_t) 
             (= v1_{1}_0 v1_{0}_t) (= ph1_{1}_0 ph1_{0}_t) (= th1_{1}_0 th1_{0}_t)))
(assert (or
  (and (= mode_{0} 1)
       (or (and (= mode_{1} 3)  (< (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2))) 
           (and (= mode_{1} 2)  (> (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))) 
           (and (= mode_{1} 1) (>= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2)) 
                               (<= (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2)))))
  (and (= mode_{0} 2)
       (or (and (= mode_{1} 2) (> (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))) 
           (and (= mode_{1} 1) (<=  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 10 2))))) 
  (and (= mode_{0} 3)
       (or (and (= mode_{1} 3) (< (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2))) 
           (and (= mode_{1} 1) (>=  (+ (^ (- x0_{0}_t x1_{0}_t) 2) (^ (- y0_{0}_t y1_{0}_t) 2)) (^ 5 2)))))))
"""]

