#!/bin/bash

# Supposed to be executed inside each model directory (such as airplane).
#   first argument: bound
#   other argument: python files that generates smt2
#   result: .output to contain the SMT result and time
#
# For example, in the thermostat directory, running
#   runtest.sh 5 thermostat-*.py
# will perform analysis for all thermostat models up to bound 5


# Please choose the right version for your platform
DREAL=../dReal.darwin

if [ ! -x "$DREAL" ]
then
    echo $DREAL is not found or executable;
    exit 1
fi

if $DREAL --version > /dev/null;
then
    for cmd in "${@:2}"
    do
	for b in $(seq 0 $1);
	do
	    OUTPUT=${cmd%%.*}_$b.output;
	    echo "schedule to run: " $cmd $b;
	    { { time python $cmd $b | $DREAL > $OUTPUT 2> /dev/null; } 2>> $OUTPUT & };
	done
    done
else
    echo please choose the right version of \$DREAL for your platform
fi

