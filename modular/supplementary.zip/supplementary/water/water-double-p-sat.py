
# import the model.
from waterDoubleP import *


#############
# Init/Goal #
#############

# Define initial conditions for each variable. For example, the expression
# (= tau_{0}_0 0) declares that the value of tau at the beginning is 0, 
# where {0} will be replaced by 0.
init_cond = """
(assert (= tau_{0}_0 0))
(assert (= mode1_{0} true))
(assert (and (>= x1_{0}_0 (- 5 0.1)) (<= x1_{0}_0 (+ 5 0.1))))
(assert (= mode2_{0} true))
(assert (and (>= x2_{0}_0 (- 5 0.1)) (<= x2_{0}_0 (+ 5 0.1))))
"""

# Define the goal condition, where {0} will be replaced by k, the last step.
goal_cond = """
(assert (or (< x1_{0}_t (- 5 0.1)) (> x1_{0}_t (+ 5 0.1))))
(assert (or (< x2_{0}_t (- 5 0.1)) (> x2_{0}_t (+ 5 0.1))))
"""

# Generate the smt2 output.
import sys
try:
    bound = int(sys.argv[1])
except:
    print("Usage:", sys.argv[0], "<Bound>")
else:
    generate(bound, 1, [0,1,2], 3, init_cond, goal_cond)

